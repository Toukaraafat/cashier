import { Component } from '@angular/core';

@Component({
  selector: 'app-pills',
  imports: [],
  templateUrl: './pills.component.html',
  styleUrl: './pills.component.css'
})
export class PillsComponent {

}
